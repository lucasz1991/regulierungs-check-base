<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Insurance;
use App\Models\InsuranceType;

class InsuranceInsuranceTypeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $huk = Insurance::where('slug', 'huk24')->first();
        $allianz = Insurance::where('slug', 'allianz')->first();

        $kfz = InsuranceType::where('slug', 'kfz')->first();
        $haftpflicht = InsuranceType::where('slug', 'haftpflicht')->first();

        if ($huk && $kfz) {
            $huk->insuranceTypes()->attach($kfz->id, ['order_column' => 0]);
            $huk->insuranceTypes()->attach($haftpflicht->id, ['order_column' => 1]);
        }

        if ($allianz && $kfz) {
            $allianz->insuranceTypes()->attach($kfz->id, ['order_column' => 0]);
        }
    }
}
