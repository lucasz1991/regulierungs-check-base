<?php

namespace App\Livewire\Customer\Rating;

use Livewire\Component;
use App\Models\InsuranceType;
use App\Models\RatingQuestion;

class RatingForm extends Component
{
    public $insuranceTypeId = null;
    public $insuranceType;
    public $is_closed = null;       // abgeschlossen: true/false
    public $started_at = null;      // Startdatum
    public $ended_at = null;        // Enddatum
    public $questions = [];
    public $step = 0;
    public $standardSteps = 3;
    public $totalSteps = 0;
    public $answers = [];

    public function updatedInsuranceTypeId()
    {
        $this->insuranceType = InsuranceType::find($this->insuranceTypeId);
        $this->loadQuestions();
        $this->step = 1;
    }

    public function loadQuestions()
    {
        $this->questions = $this->insuranceType
            ->ratingQuestions()
            ->orderBy('insurance_type_rating_question.order_column')
            ->get();
        $this->totalSteps = $this->standardSteps + ($this->questions->count()-1); // 3 Standardfragen + dynamische

    }

    public function nextStep()
    {
        if ($this->step < count($this->questions)+3) {
            $this->step++;
        }
    }

    public function previousStep()
    {
        if ($this->step > 0) {
            $this->step--;
        }
    }

    public function submit()
    {
        $this->validate($this->rules());

        // Beispiel: Speichern in der Datenbank
        // RatingSubmission::create([...]);
        $this->step = -1; // Bewertung abgeschlossen
        session()->flash('message', 'Vielen Dank für deine Bewertung!');
    }

    public function rules()
    {
        $rules = [];
    
        if ($this->step >= 1) {
            $rules['is_closed'] = 'required|boolean';
        }
    
        if ($this->step >= 2) {
            $rules['started_at'] = 'required|date';
            if ($this->is_closed) {
                $rules['ended_at'] = 'required|date|after_or_equal:started_at';
            }
        }
    
        if ($this->step >= 3) {
            foreach ($this->questions as $q) {
                if ($q->is_required) {
                    $rules["answers.{$q->id}"] = 'required';
                }
            }
        }
    
        return $rules;
    }

    public function render()
    {
        return view('livewire.customer.rating.rating-form', [
            'types' => InsuranceType::all()
        ]);
    }
}
