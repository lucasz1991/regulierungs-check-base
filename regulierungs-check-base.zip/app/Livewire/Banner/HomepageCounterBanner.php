<?php

namespace App\Livewire\Banner;

use Livewire\Component;

class HomepageCounterBanner extends Component
{
    public function render()
    {
        return view('livewire.banner.homepage-counter-banner');
    }
}
