<?php

namespace App\Livewire\Pages;

use Livewire\Component;

class Ranking extends Component
{
    public function render()
    {
        return view('livewire.pages.ranking')->layout('layouts.app');
    }
}
