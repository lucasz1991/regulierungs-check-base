<?php

namespace App\Livewire\Pages;

use Livewire\Component;
use App\Models\Insurance;

class Ranking extends Component
{
    public $rankings;

    public function mount()
    {
        $this->rankings = Insurance::withCount(['claimRatings as total_ratings'])
            ->withAvg('claimRatings as average_rating', 'rating')
            ->withCount([
                'claimRatings as full_payments' => function ($query) {
                    $query->where('regulation_type', 'vollzahlung');
                }
            ])
            ->orderByDesc('average_rating')
            ->take(10)
            ->get()
            ->map(function ($insurance) {
                $insurance->full_payment_rate = $insurance->total_ratings > 0
                    ? round($insurance->full_payments / $insurance->total_ratings * 100, 1)
                    : null;
                return $insurance;
            });
    }

    public function render()
    {
        return view('livewire.pages.ranking')->layout('layouts.app');
    }
}
