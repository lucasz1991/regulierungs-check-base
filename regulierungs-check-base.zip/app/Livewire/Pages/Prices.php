<?php

namespace App\Livewire\Pages;

use Livewire\Component;

class Prices extends Component
{
    public function render()
    {
        return view('livewire.pages.prices')->layout('layouts.app');
    }
}
