<?php

namespace App\Livewire\Pages;

use Livewire\Component;

class Premium extends Component
{
    public function render()
    {
        return view('livewire.pages.premium')->layout('layouts.app');
    }
}
