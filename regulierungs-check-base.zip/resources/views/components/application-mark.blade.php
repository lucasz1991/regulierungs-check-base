<img 
    class="max-h-12 {{ $class ?? '' }}" 
    src="{{ asset('/site-images/logo-xs.png') }}" 
    alt="Logo">