<img 
    class="w-full max-w-32 {{ $class ?? '' }}" 
    src="{{ asset('/site-images/logo/logo-icon.png') }}" 
    alt="Logo">
