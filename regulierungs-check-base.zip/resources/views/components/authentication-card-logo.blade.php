<a href="/" class="w-40 block">
<img 
    class="max-w-32 {{ $class ?? '' }}" 
    src="{{ asset('/site-images/logo-xs.png') }}" 
    alt="ShopSpaze Logo">
</a>
