<img 
    class="w-full max-w-32 {{ $class ?? '' }}" 
    src="{{ asset('/site-images/icon.png') }}" 
    alt="ShopSpaze Logo">