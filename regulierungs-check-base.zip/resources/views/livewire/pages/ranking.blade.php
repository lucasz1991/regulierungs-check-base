<section class="text-gray-600 body-font">
  <div class="container px-5 py-24 mx-auto">
    <div class="flex flex-col text-center w-full mb-12">
      <h1 class="sm:text-3xl text-2xl font-medium title-font text-gray-900">Top-Versicherungen im Ranking</h1>
      <p class="lg:w-2/3 mx-auto leading-relaxed text-base mt-4">
        Basierend auf Nutzerbewertungen – sortiert nach Zufriedenheit, Anzahl an Bewertungen und wie oft voll gezahlt wurde.
      </p>
    </div>

    <div class="overflow-x-auto">
      <table class="table-auto w-full text-left whitespace-no-wrap bg-white shadow rounded-lg">
        <thead class="bg-gray-100 text-gray-700 text-sm uppercase tracking-wider">
          <tr>
            <th class="px-6 py-3">Platz</th>
            <th class="px-6 py-3">Versicherung</th>
            <th class="px-6 py-3">Ø Bewertung</th>
            <th class="px-6 py-3">Anzahl Bewertungen</th>
            <th class="px-6 py-3">Vollzahlungsquote</th>
          </tr>
        </thead>
        <tbody>
          @foreach ($rankings as $index => $insurance)
            <tr class="border-b hover:bg-gray-50">
              <td class="px-6 py-4 font-bold">{{ $index + 1 }}</td>
              <td class="px-6 py-4">{{ $insurance->name }}</td>
              <td class="px-6 py-4">{{ number_format($insurance->average_rating, 2) }} ★</td>
              <td class="px-6 py-4">{{ $insurance->total_ratings }}</td>
              <td class="px-6 py-4">
                {{ $insurance->full_payment_rate !== null ? $insurance->full_payment_rate . '%' : '–' }}
              </td>
            </tr>
          @endforeach
        </tbody>
      </table>
    </div>
  </div>
</section>
