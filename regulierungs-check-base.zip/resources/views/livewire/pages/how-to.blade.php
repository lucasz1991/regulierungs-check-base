<div class="bg-[#fafeff]" wire:loading.class="cursor-wait">
<livewire:admin.tools.tests.ai-analysis-test />
</div>
