<div class="" wire:loading.class="cursor-wait">

</div>
